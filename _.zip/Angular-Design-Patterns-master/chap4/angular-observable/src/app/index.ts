export * from './environment';
export * from './angular-observable.component';

console.log(new Date().getTime());