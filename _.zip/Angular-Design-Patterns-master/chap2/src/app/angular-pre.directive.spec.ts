import { AngularPreDirective } from './angular-pre.directive';

describe('AngularPreDirective', () => {
  it('should create an instance', () => {
    const directive = new AngularPreDirective();
    expect(directive).toBeTruthy();
  });
});
