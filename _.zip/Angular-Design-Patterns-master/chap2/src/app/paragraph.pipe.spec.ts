import { ParagraphPipe } from './paragraph.pipe';

describe('ParagraphPipe', () => {
  it('create an instance', () => {
    const pipe = new ParagraphPipe();
    expect(pipe).toBeTruthy();
  });
});
