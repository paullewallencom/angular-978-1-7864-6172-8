import { ReplaceAllPipe } from './replace-all.pipe';

describe('ReplaceAllPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplaceAllPipe();
    expect(pipe).toBeTruthy();
  });
});
